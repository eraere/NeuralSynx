using MoodTuness.Models;

namespace MoodTuness.Services;

public interface IFavoritesService
{
    List<Track> GetFavorites();
    void AddToFavorites(Track track);
    void RemoveFromFavorites(Track track);
    bool IsFavorite(Track track);
    event Action? OnFavoritesChanged;
}

public class FavoritesService : IFavoritesService
{
    private readonly List<Track> _favorites = new();
    public event Action? OnFavoritesChanged;

    public List<Track> GetFavorites() => _favorites;

    public void AddToFavorites(Track track)
    {
        if (!IsFavorite(track))
        {
            _favorites.Add(track);
            OnFavoritesChanged?.Invoke();
        }
    }

    public void RemoveFromFavorites(Track track)
    {
        if (_favorites.RemoveAll(t => t.Title == track.Title && t.Artist == track.Artist) > 0)
        {
            OnFavoritesChanged?.Invoke();
        }
    }

    public bool IsFavorite(Track track)
    {
        return _favorites.Any(t => t.Title == track.Title && t.Artist == track.Artist);
    }
} 