using SpotifyAPI.Web;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Logging;
using MoodTuness.Models;

namespace MoodTuness.Services;

public interface IPlaylistService
{
    Task<Playlist> GeneratePlaylistForMood(string mood, string frequency);
}

public class PlaylistService : IPlaylistService
{
    private readonly SpotifyClient _spotify;
    private readonly ILogger<PlaylistService> _logger;
    private readonly Dictionary<string, string> _moodSearchTerms;

    public PlaylistService(IOptions<SpotifySettings> spotifySettings, ILogger<PlaylistService> logger)
    {
        _logger = logger;
        var config = SpotifyClientConfig
            .CreateDefault()
            .WithAuthenticator(new ClientCredentialsAuthenticator(
                spotifySettings.Value.ClientId,
                spotifySettings.Value.ClientSecret));

        _spotify = new SpotifyClient(config);

        _moodSearchTerms = new Dictionary<string, string>
        {
            { "EUPHORIA", "upbeat electronic euphoric" },
            { "SERENITY", "ambient peaceful meditation" },
            { "FOCUS", "focus concentration study" },
            { "MELANCHOLY", "melancholic sad emotional" },
            { "PASSION", "passionate intense dramatic" },
            { "ENERGY", "energetic powerful workout" },
            { "ETHEREAL", "ethereal atmospheric ambient" },
            { "COSMIC", "space cosmic ambient" }
        };
    }

    public async Task<Playlist> GeneratePlaylistForMood(string mood, string frequency)
    {
        try
        {
            var searchTerm = _moodSearchTerms[mood];
            var searchRequest = new SearchRequest(SearchRequest.Types.Track, searchTerm)
            {
                Limit = 5,
                Market = "US"
            };

            var searchResponse = await _spotify.Search.Item(searchRequest);
            
            if (searchResponse.Tracks.Items == null || !searchResponse.Tracks.Items.Any())
            {
                _logger.LogWarning("No tracks found for mood: {Mood}", mood);
                return await GenerateDemoPlaylist(mood, frequency);
            }

            var tracks = searchResponse.Tracks.Items
                .Select(track => new Track
                {
                    Title = track.Name,
                    Artist = string.Join(", ", track.Artists.Select(a => a.Name)),
                    Duration = FormatDuration(track.DurationMs),
                    Frequency = frequency
                })
                .ToList();

            return new Playlist
            {
                MoodName = mood,
                Frequency = frequency,
                Tracks = tracks
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generating playlist for mood: {Mood}", mood);
            return await GenerateDemoPlaylist(mood, frequency);
        }
    }

    private async Task<Playlist> GenerateDemoPlaylist(string mood, string frequency)
    {
        // Simulate API delay
        await Task.Delay(1500);

        var tracks = new List<Track>
        {
            new Track { Title = "Neural Drift", Artist = "Synth.AI", Duration = "4:23", Frequency = frequency },
            new Track { Title = "Quantum Resonance", Artist = "Digital Monks", Duration = "3:45", Frequency = frequency },
            new Track { Title = "Cybernetic Dreams", Artist = "Neural.Pulse", Duration = "5:12", Frequency = frequency },
            new Track { Title = "Binary Sunset", Artist = "Code Architects", Duration = "4:56", Frequency = frequency },
            new Track { Title = "Digital Awakening", Artist = "Circuit.Mind", Duration = "3:33", Frequency = frequency }
        };

        return new Playlist
        {
            MoodName = mood,
            Frequency = frequency,
            Tracks = tracks
        };
    }

    private string FormatDuration(int milliseconds)
    {
        var timeSpan = TimeSpan.FromMilliseconds(milliseconds);
        return $"{(int)timeSpan.TotalMinutes}:{timeSpan.Seconds:D2}";
    }
} 