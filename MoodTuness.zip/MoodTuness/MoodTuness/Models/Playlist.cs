namespace MoodTuness.Models;

public class Track
{
    public required string Title { get; set; }
    public required string Artist { get; set; }
    public required string Duration { get; set; }
    public required string Frequency { get; set; }
}

public class Playlist
{
    public required string MoodName { get; set; }
    public required string Frequency { get; set; }
    public required List<Track> Tracks { get; set; }
} 